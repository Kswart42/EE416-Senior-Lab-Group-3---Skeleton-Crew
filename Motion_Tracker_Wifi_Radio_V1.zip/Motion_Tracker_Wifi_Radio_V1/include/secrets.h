#pragma once

// Put this file in your project's include/ folder.
//
// imu1 creates this network. imu2 and your PC join it.
// Password must be at least 8 characters.
#define AP_SSID "IMU-NET"
#define AP_PASS "imutrack123"

#define UDP_PORT 4210
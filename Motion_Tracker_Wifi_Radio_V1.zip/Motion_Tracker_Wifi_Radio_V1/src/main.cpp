/*
  ESP32-S3-DevKitC-1 + MPU-6050: IMU + RSSI ranging streamed over Wi-Fi (UDP)
  ---------------------------------------------------------------------------
  Each packet is one CSV line:
    id,device_ms,ax,ay,az,gx,gy,gz,roll,pitch,yaw,rssi
  Units: accel m/s^2, gyro rad/s, angles degrees, rssi dBm (0 = no link).

  rssi is the signal strength of the link between the two boards, measured
  by imu2 (the joiner) as it hears imu1 (the access point). imu1 sends 0
  because the PC is also a station on its network, so it can't tell which
  station is imu2. The PC turns imu2's rssi into a distance estimate
  (see receiver_ranging.py).

  Wiring: SDA -> GPIO8, SCL -> GPIO9, VIN -> 3V3, GND -> GND

  Set DEVICE_ID per board using the imu1 / imu2 environments in
  platformio.ini. Network name/password live in include/secrets.h.
  imu1 is the access point.
*/

#include <Arduino.h>
#include <Adafruit_MPU6050.h>
#include <Adafruit_Sensor.h>
#include <Wire.h>
#include <WiFi.h>
#include <WiFiUdp.h>
#include "secrets.h"

#ifndef DEVICE_ID
#define DEVICE_ID 1
#endif

// IS_AP=1: this board creates the Wi-Fi network. IS_AP=0: it joins it.
#ifndef IS_AP
#define IS_AP 1
#endif

Adafruit_MPU6050 mpu;
WiFiUDP udp;
IPAddress destIP;

constexpr int SDA_PIN = 8;
constexpr int SCL_PIN = 9;

constexpr float    ALPHA       = 0.98f;
constexpr uint32_t LOOP_US     = 10000;  // 100 Hz sensor + send rate
constexpr uint8_t  PRINT_EVERY = 10;     // Serial print at 10 Hz (debug only)
constexpr uint8_t  RSSI_EVERY  = 5;      // sample link RSSI at 20 Hz
constexpr float    RSSI_SMOOTH = 0.1f;   // EMA weight: lower = smoother but slower

float roll = 0.0f, pitch = 0.0f, yaw = 0.0f;
float gyroBiasX = 0.0f, gyroBiasY = 0.0f, gyroBiasZ = 0.0f;
uint32_t lastUpdateMicros = 0;

float rssiAvg = 0.0f;  // smoothed link RSSI in dBm, 0 = no link yet

// No router needed: imu1 creates its own network, imu2 and the PC join it.
bool netReady() {
#if IS_AP
  return true;  // an access point is always "up"
#else
  return WiFi.status() == WL_CONNECTED;
#endif
}

// Raw RSSI of the link to the other board right now. Returns 0 if no link.
// Only imu2 measures it: it hears the access point (imu1) directly.
int readLinkRssi() {
#if IS_AP
  return 0;
#else
  if (WiFi.status() == WL_CONNECTED) return WiFi.RSSI();
  return 0;
#endif
}

void updateRssi() {
  int r = readLinkRssi();
  if (r == 0) {
    rssiAvg = 0.0f;  // link lost / nobody connected
    return;
  }
  if (rssiAvg == 0.0f) rssiAvg = (float)r;  // first sample seeds the filter
  else rssiAvg += RSSI_SMOOTH * ((float)r - rssiAvg);
}

void connectWiFi() {
  // Broadcast address of the board's own network (192.168.4.x)
  destIP = IPAddress(192, 168, 4, 255);

#if IS_AP
  WiFi.mode(WIFI_AP);
  bool apOk = WiFi.softAP(AP_SSID, AP_PASS, 1, 0, 4);  // channel 1, visible, max 4 clients
  Serial.print("Access point ");
  Serial.print(apOk ? "STARTED: " : "FAILED to start: ");
  Serial.println(AP_SSID);
  Serial.print("AP IP: ");
  Serial.println(WiFi.softAPIP());
#else
  WiFi.mode(WIFI_STA);
  WiFi.setSleep(false);  // lower latency, steadier packet timing
  WiFi.begin(AP_SSID, AP_PASS);

  Serial.print("Joining ");
  Serial.print(AP_SSID);
  uint32_t start = millis();
  while (WiFi.status() != WL_CONNECTED && millis() - start < 20000) {
    delay(500);
    Serial.print(".");
  }
  Serial.println();
  if (WiFi.status() == WL_CONNECTED) {
    Serial.print("Joined. Board IP: ");
    Serial.println(WiFi.localIP());
  } else {
    Serial.println("Could not join yet (is imu1 powered on?). Will keep retrying.");
  }
#endif
}

void calibrateGyro(int samples = 500) {
  while (true) {
    Serial.println("Calibrating gyro... keep the sensor still.");
    float sum[3] = {0, 0, 0};
    float mn[3]  = { 1e9f,  1e9f,  1e9f};
    float mx[3]  = {-1e9f, -1e9f, -1e9f};

    for (int i = 0; i < samples; i++) {
      sensors_event_t a, g, t;
      mpu.getEvent(&a, &g, &t);
      float v[3] = {g.gyro.x, g.gyro.y, g.gyro.z};
      for (int k = 0; k < 3; k++) {
        sum[k] += v[k];
        if (v[k] < mn[k]) mn[k] = v[k];
        if (v[k] > mx[k]) mx[k] = v[k];
      }
      delay(3);
    }

    bool still = true;
    for (int k = 0; k < 3; k++) {
      if (mx[k] - mn[k] > 0.1f) still = false;
    }
    if (!still) {
      Serial.println("Motion detected during calibration, retrying...");
      continue;
    }

    gyroBiasX = sum[0] / samples;
    gyroBiasY = sum[1] / samples;
    gyroBiasZ = sum[2] / samples;
    Serial.println("Calibration complete.");
    return;
  }
}

void initAnglesFromAccel() {
  sensors_event_t a, g, t;
  mpu.getEvent(&a, &g, &t);
  float ax = a.acceleration.x, ay = a.acceleration.y, az = a.acceleration.z;
  roll  = atan2f(ay, az);
  pitch = atan2f(-ax, sqrtf(ay * ay + az * az));
  yaw   = 0.0f;
}

void setup() {
  Serial.begin(115200);
  delay(2000);

  Serial.printf("Device ID: %d  Role: %s\n", DEVICE_ID, IS_AP ? "ACCESS POINT" : "JOINER");

  // Start networking FIRST so the Wi-Fi is visible even if the IMU has a problem
  connectWiFi();

  Serial.println("Initializing MPU6050...");

  Wire.begin(SDA_PIN, SCL_PIN);
  Wire.setClock(400000);

  if (!mpu.begin()) {
    Serial.println("Failed to find MPU6050. Check wiring/address.");
    while (1) delay(10);
  }
  Serial.println("MPU6050 found!");

  mpu.setAccelerometerRange(MPU6050_RANGE_8_G);
  mpu.setGyroRange(MPU6050_RANGE_500_DEG);
  mpu.setFilterBandwidth(MPU6050_BAND_21_HZ);

  delay(100);
  calibrateGyro();
  initAnglesFromAccel();

  udp.begin(UDP_PORT);  // local socket (we only send, but this is harmless)
  lastUpdateMicros = micros();
}

void loop() {
  uint32_t now = micros();
  if (now - lastUpdateMicros < LOOP_US) {
    delay(1);
    return;
  }
  float dt = (now - lastUpdateMicros) * 1e-6f;
  lastUpdateMicros = now;

  sensors_event_t a, g, temp;
  mpu.getEvent(&a, &g, &temp);

  float gx = g.gyro.x - gyroBiasX;
  float gy = g.gyro.y - gyroBiasY;
  float gz = g.gyro.z - gyroBiasZ;
  float ax = a.acceleration.x, ay = a.acceleration.y, az = a.acceleration.z;

  float accelRoll  = atan2f(ay, az);
  float accelPitch = atan2f(-ax, sqrtf(ay * ay + az * az));

  roll  = ALPHA * (roll  + gx * dt) + (1.0f - ALPHA) * accelRoll;
  pitch = ALPHA * (pitch + gy * dt) + (1.0f - ALPHA) * accelPitch;
  yaw  += gz * dt;

  // ---- Link strength (used by the PC for distance estimation) ----
  static uint8_t rn = 0;
  if (++rn >= RSSI_EVERY) {
    rn = 0;
    updateRssi();
  }

  // ---- Send over Wi-Fi ----
#if !IS_AP
  // If imu2 wasn't able to join (or lost the link), keep trying
  static uint32_t lastRetry = 0;
  if (WiFi.status() != WL_CONNECTED && millis() - lastRetry > 5000) {
    lastRetry = millis();
    WiFi.disconnect();
    WiFi.begin(AP_SSID, AP_PASS);
  }
#endif

  if (netReady()) {
    char buf[192];
    int len = snprintf(buf, sizeof(buf),
                       "%d,%lu,%.3f,%.3f,%.3f,%.4f,%.4f,%.4f,%.2f,%.2f,%.2f,%.1f\n",
                       DEVICE_ID, (unsigned long)millis(),
                       ax, ay, az, gx, gy, gz,
                       roll * RAD_TO_DEG, pitch * RAD_TO_DEG, yaw * RAD_TO_DEG,
                       rssiAvg);
    udp.beginPacket(destIP, UDP_PORT);
    udp.write((const uint8_t *)buf, len);
    udp.endPacket();
  }

  // ---- Low-rate Serial print for debugging ----
  static uint8_t n = 0;
  if (++n >= PRINT_EVERY) {
    n = 0;
    Serial.printf("roll:%.2f,pitch:%.2f,yaw:%.2f,wifi:%d,rssi:%.1f\n",
                  roll * RAD_TO_DEG, pitch * RAD_TO_DEG, yaw * RAD_TO_DEG,
                  netReady(), rssiAvg);
  }
}